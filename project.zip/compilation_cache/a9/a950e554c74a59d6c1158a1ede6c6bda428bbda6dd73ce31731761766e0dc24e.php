<?php

/* artists.html */
class __TwigTemplate_496c1aca6e1fb61d8c96606a21884e3aac4c4d20d6a39c5370b4d93dad7cd361 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("index.html", "artists.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["artists"]) ? $context["artists"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["artist"]) {
            // line 4
            echo "<div class=\"item\" style=\"background-image: url(./images/artists/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["artist"], "artist_picture", array()), "html", null, true);
            echo ");\">
\t<a href=\"/artists/";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute($context["artist"], "artist_id", array()), "html", null, true);
            echo "\">
\t\t<div class=\"overlay\">
\t\t\t<div class=\"title\">
\t\t\t\t<span>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["artist"], "artist_name", array()), "html", null, true);
            echo "</span>
\t\t\t</div>
\t\t</div>
\t</a>
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['artist'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "<div class=\"clearfix\"></div>
<div class=\"paginations text-center\">
\t<a href=\"#\" class=\"prev-pgn\"><span class=\"glyphicon glyphicon-backward\"></span></a>
\t<a href=\"#\" class=\"pgn pgn-current\">1</a>
\t<a href=\"#\" class=\"pgn\">2</a>
\t<a href=\"#\" class=\"pgn\">3</a>
\t<a href=\"#\" class=\"pgn\">4</a>
\t<span style=\"color: #fff\">...</span>
\t<a href=\"#\" class=\"pgn\">22</a>
\t<a href=\"#\" class=\"next-pgn\"><span class=\"glyphicon glyphicon-forward\"></span></a>
</div>
";
    }

    public function getTemplateName()
    {
        return "artists.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  46 => 8,  40 => 5,  35 => 4,  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSource()
    {
        return "";
    }
}
