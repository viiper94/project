<?php

/* releases.html */
class __TwigTemplate_8b40a1fc12cedf2e9b1cef5cde2818d7e17c51ef48d7f1d02184d0d2533c6eb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("index.html", "releases.html", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "index.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["release"]) ? $context["release"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 4
            echo "<div class=\"item\" style=\"background-image: url(/images/releases/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "release_cover", array()), "html", null, true);
            echo ");\">
\t<a href=\"/releases/";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "releases_id", array()), "html", null, true);
            echo "\">
\t\t<div class=\"overlay\">
\t\t\t<div class=\"title\">
\t\t\t\t<span>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "release_title", array()), "html", null, true);
            echo "</span>
\t\t\t</div>
\t\t</div>
\t</a>
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "<div class=\"clearfix\"></div>
<div class=\"paginations text-center\">
\t<a href=\"#\" class=\"prev-pgn\"><span class=\"glyphicon glyphicon-backward\"></span></a>
\t<a href=\"#\" class=\"pgn pgn-current\">1</a>
\t<a href=\"#\" class=\"pgn\">2</a>
\t<a href=\"#\" class=\"pgn\">3</a>
\t<a href=\"#\" class=\"pgn\">4</a>
\t<span style=\"color: #fff\">...</span>
\t<a href=\"#\" class=\"pgn\">22</a>
\t<a href=\"#\" class=\"next-pgn\"><span class=\"glyphicon glyphicon-forward\"></span></a>
</div>
";
    }

    public function getTemplateName()
    {
        return "releases.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  46 => 8,  40 => 5,  35 => 4,  31 => 3,  28 => 2,  11 => 1,);
    }

    public function getSource()
    {
        return "";
    }
}
