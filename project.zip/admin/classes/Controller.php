<?php
require_once CLASS_DIR . 'View.php';
require_once CLASS_DIR . 'models/DataModel.php';
require_once CLASS_DIR . 'models/SortModel.php';
require_once CLASS_DIR . 'models/PageModel.php';

class Controller{
	
	public $model;
	public $sort;
	public $view;

}