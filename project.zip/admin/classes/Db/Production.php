<?php
class Production {
    protected $user     = "root";
    protected $password = "root";
    protected $db_name  = "viiper94";
    protected $host     = "localhost";
}