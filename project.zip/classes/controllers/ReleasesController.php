<?php
require_once CLASS_DIR . 'Controller.php';

class ReleasesController extends Controller{

    function __construct(){
        $this->model = new MainModel('releases', array(
            'id' => 'releases_id',
            'title' => 'release_title',
            'picture' => 'release_cover',
            'related' => 'release_related',
        ));
    }

    function actionReleases(){
        if(!empty($_GET['id'])){
            $id = $_GET['id'];
            $data['item'] = $this->model->getDataById($id);
            $data['related'] = $this->model->getRelatedData($id);
            $data['next'] = $this->model->getNextData($id);
            $data['prev'] = $this->model->getPrevData($id);
            View::generateView('release', $data);
        } else{
            $data['release'] = $this->model->getSortedData(array(
                'releases_id',
                'release_title',
                'release_cover',
                'sort'
            ));
            View::generateView('releases', $data);
        }
    }
	
}