<?php
require_once CLASS_DIR . '/Controller.php';

class SchoolController extends Controller{
	
	function actionSchool(){
		View::generateView('school');
	}
	
}