<?php
require_once CLASS_DIR . 'Controller.php';

class ErrorController extends Controller{
	
	static public function actionError(){
		View::generateView('404');
	}
	
}