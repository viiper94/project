<?php
require_once CLASS_DIR . 'View.php';
require_once CLASS_DIR . 'models/MainModel.php';

class Controller{
	
	public $model;
	
}